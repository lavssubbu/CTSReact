import React,{Component} from 'react';

class Welcome extends Component{

    constructor(props)
    {
        super(props)
        this.state = { message : 'Welcome to React'};
    }
    changeMessage = () => {
        this.setState({message : 'You clicked the button!'});
    }
    render()
    {
        return (
        <>
        <h1>{this.state.message}</h1>
        <h2>{this.props.name}</h2>
        <button  onClick={this.changeMessage}>Click Me</button>
        </>
        )
    }
}

export default Welcome;