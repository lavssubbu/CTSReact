import React,{useState} from "react";
import ProductDetail from "./ProductDetail";
import { useNavigate } from "react-router-dom";

const ProductList = () => {
   // const [selectedProduct, setSelectedProduct] = useState(null);
    const navigate=useNavigate();
    const prods = [
        { id: 1, name: 'iPhone' },
        { id: 2, name: 'Laptop' }
    ];

    const handleProductClick = (product) => {
        navigate(`/product/${product.id}`,{state:product})
       // setSelectedProduct(product);
    };

    return (
        <div>
            <h3>Product List</h3>
            {prods.map((p) => (
                <div key={p.id}>
                    <h4>{p.name}</h4>
                    <button onClick={() => handleProductClick(p)}>View Details</button>
                </div>
            ))}
   </div>    
    );
};

export default ProductList;


