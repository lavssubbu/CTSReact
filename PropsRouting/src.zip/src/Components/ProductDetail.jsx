import React from "react"
import { useLocation, useParams } from "react-router-dom";


const ProductDetail = () =>
{
    const {id}=useParams();
    const location = useLocation();
    const product = location.state;

  return(
    <div>
        <h2>Product Detail</h2>
        <p>ID:{id}</p>
        <p>ProductName:{product.name}</p>
    </div>
  )
}

export default ProductDetail;