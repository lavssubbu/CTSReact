import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Welcome from './Welcome'
import ProductList from './Components/ProductList'
import ProductDetail from './Components/ProductDetail'
import {BrowserRouter as Router,Route, Routes } from 'react-router-dom'

function App() {
   return (
    <Router>
     <Routes>
     <Route exact path="/" element={<ProductList/>} />
     <Route path="/product/:id" element={<ProductDetail/>} />
     </Routes>
    </Router>    
  )
}

export default App
