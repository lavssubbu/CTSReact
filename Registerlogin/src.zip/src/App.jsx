import React from 'react'
import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import {  Routes, Route } from 'react-router-dom';
import  AppProvider from './Context/AppContext'
import Login from './Components/Login'
import Register from './Components/Register'
import PostList from './Components/PostList'
import PostEdit from './Components/PostEdit'
import PostDelete from './Components/PostDelete'
import PostAdd from './Components/PostAdd'

function App() {
  return (
    <>
     
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/posts" element={<PostList />} />
        <Route path="/add" element={<PostAdd />} />
        <Route path="/edit/:id" element={<PostEdit />} />
        <Route path="/delete/:id" element={<PostDelete />} />
      </Routes>

    </>
  )
}

export default App
