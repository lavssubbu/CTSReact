import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import axios from "axios";

const PostEdit = () => {
  const { id } = useParams();
  const [post, setPost] = useState({ title: "", content: "" });
  const navigate = useNavigate();

  useEffect(() => {
    // Fetch the post data from the mock API (JSON Server)
    axios.get(`http://localhost:3000/posts/${id}`).then((response) => {
      setPost(response.data);
    });
  }, [id]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    // Update the post data in the mock API
    await axios.put(`http://localhost:3000/posts/${id}`, post);
    navigate("/posts"); // Redirect to the posts list page
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Edit Post</h2>
      <input
        type="text"
        placeholder="Title"
        value={post.title}
        onChange={(e) => setPost({ ...post, title: e.target.value })}
        required
      />
      <textarea
        placeholder="Content"
        value={post.content}
        onChange={(e) => setPost({ ...post, content: e.target.value })}
        required
      ></textarea>
      <button type="submit">Update Post</button>
    </form>
  );
};

export default PostEdit;
