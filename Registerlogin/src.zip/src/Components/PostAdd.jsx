import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import axios from "axios";

const PostAdd = () => {
  const { id } = useParams(); // If updating, get the post id from the URL
  const navigate = useNavigate();

  // Initialize the state for post data (id, title, content)
  const [post, setPost] = useState({
    id: "",
    title: "",
    content: "",
  });

  useEffect(() => {
    // If an id exists, we are in edit mode
    if (id) {
      axios
        .get(`http://localhost:3001/posts/${id}`)
        .then((response) => {
          setPost(response.data); // Set the post data in the form
        })
        .catch((error) => {
          console.error("Error fetching post data:", error);
        });
    }
  }, [id]);

  // Handle form input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setPost((prevPost) => ({
      ...prevPost,
      [name]: value,
    }));
  };

  // Handle form submission (add or update post)
  const handleSubmit = async (e) => {
    e.preventDefault();

    // If there's an id, update the post, otherwise create a new one
    if (id) {
      // Update existing post
      await axios.put(`http://localhost:3000/posts/${id}`, post);
       navigate("/posts"); 
    } else {
      // Add new post
      await axios.post("http://localhost:3000/posts", post);
       navigate("/posts", { state: { refresh: true } }); 
    }

   // Redirect to the posts list after submit
  };

  return (
    <form onSubmit={handleSubmit}>
      
        <div>
          <label>Post ID:</label>
          <input
            type="text"
            name="id"
            value={post.id}
            onChange={handleChange}
             required
          
          />
        </div>
      

      {/* Post Title Field */}
      <div>
        <label>Title:</label>
        <input
          type="text"
          name="title"
          value={post.title}
          onChange={handleChange}
          required
        />
      </div>

      {/* Post Content Field */}
      <div>
        <label>Content:</label>
        <textarea
          name="content"
          value={post.content}
          onChange={handleChange}
          required
        />
      </div>

      <button type="submit">{id ? "Update Post" : "Add Post"}</button>
    </form>
  );
};

export default PostAdd;
