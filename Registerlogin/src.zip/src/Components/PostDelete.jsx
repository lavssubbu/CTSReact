import { useNavigate, useParams } from "react-router-dom";
import axios from "axios";

const PostDelete = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const handleDelete = async () => {
    // Delete the post data from the mock API
    await axios.delete(`http://localhost:3000/posts/${id}`);
    navigate("/posts"); // Redirect to the posts list page
  };

  return (
    <div>
      <h2>Are you sure you want to delete this post?</h2>
      <button onClick={handleDelete}>Yes, Delete</button>
      <button onClick={() => navigate("/posts")}>Cancel</button>
    </div>
  );
};

export default PostDelete;
