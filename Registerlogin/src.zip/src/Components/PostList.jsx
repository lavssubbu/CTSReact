import { useEffect, useState ,useContext} from "react";
import { useLocation ,Link} from "react-router-dom";
import axios from "axios";
import { AppContext } from "../Context/AppContext";

const PostList = () => {
  const [posts, setPosts] = useState([]);
  const location = useLocation();
  const { user } = useContext(AppContext); 
  // Custom function to load posts from backend
  const fetchPosts = async () => {
    try {
      const response = await axios.get("http://localhost:3000/posts");
      setPosts(response.data);
    } catch (error) {
      console.error("Error fetching posts:", error);
    }
  };

    const deletePost = async (id) => {
    try {
      await axios.delete(`http://localhost:3000/posts/${id}`);
      fetchPosts(); // Refresh after deletion
    } catch (error) {
      console.error("Error deleting post:", error);
    }
  };

  useEffect(() => {
    // Always fetch posts when component mounts
    fetchPosts();

    // Optionally re-fetch when navigated from PostAdd with refresh flag
    if (location.state?.refresh) {
      fetchPosts();
    }
  }, [location.state]);

  return (
    <div>
      <h2>Post List</h2>
        {/* Add Post button visible only for admin */}
      {user?.role === "admin" && (
        <div style={{ marginBottom: "1rem" }}>
          <Link to="/add">
            <button>Add New Post</button>
          </Link>
        </div>
      )}
      <ul>
        {posts.map((post) => (
          <li key={post.id}>
            <strong>{post.title}</strong>: {post.content}
             <p>{post.content}</p>
            {user?.role === "admin" && (
              <>
                <Link to={`/edit/${post.id}`}>Edit</Link>
                <button onClick={() => deletePost(post.id)}>Delete</button>
              </>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default PostList;
