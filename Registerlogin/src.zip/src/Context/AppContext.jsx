import { createContext, useEffect, useState } from "react";
import axios from "axios";

export const AppContext = createContext();

export const AppProvider = ({ children }) => {
  const [user, setUser] = useState(() => JSON.parse(localStorage.getItem("user")) || null);
  const [posts, setPosts] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:3000/posts").then(res => setPosts(res.data));
  }, []);

  const login = async (username, password) => {
    const res = await axios.get("http://localhost:3000/users");
    const found = res.data.find(u => u.username === username && u.password === password);
    if (found) {
      setUser(found);
      localStorage.setItem("user", JSON.stringify(found));
      return true;
    }
    return false;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem("user");
  };

  const addPost = async (post) => {
    const res = await axios.post("http://localhost:3000/posts", post);
    setPosts([...posts, res.data]);
  };

  const updatePost = async (id, updatedPost) => {
    await axios.put(`http://localhost:3000/posts/${id}`, updatedPost);
    setPosts(posts.map(p => p.id === id ? updatedPost : p));
  };

  const deletePost = async (id) => {
    await axios.delete(`http://localhost:3000/posts/${id}`);
    setPosts(posts.filter(p => p.id !== id));
  };

  return (
    <AppContext.Provider value={{ user, login, logout, posts, addPost, updatePost, deletePost }}>
      {children}
    </AppContext.Provider>
  );
};
export default AppContext;