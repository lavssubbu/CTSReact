import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { PostProvider } from "./Context/PostContext";
import PostList from "./Components/PostList";
import PostForm from "./Components/PostForm";
import PostEdit from "./Components/PostEdit";

function App() {
   return (
    <>
      <PostProvider>
           <Router>
             <Routes>
               <Route path="/" element={<PostList />} />
               <Route path="/add" element={<PostForm />} />
               <Route path="/edit/:id" element={<PostEdit />} />
             </Routes>
           </Router>
         </PostProvider>
    </>
  )
}

export default App
