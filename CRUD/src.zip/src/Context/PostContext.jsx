import React, { createContext, useState, useEffect } from "react";
import axios from "axios";

export const PostContext = createContext();

export const PostProvider = ({ children }) => {
  const [posts, setPosts] = useState([]);

  const fetchPosts = async () => {
    const res = await axios.get("http://localhost:3000/posts");
    setPosts(res.data);
  };

  const addPost = async (post) => {
    await axios.post("http://localhost:3000/posts", post);
    fetchPosts();
  };

  const deletePost = async (id) => {
    await axios.delete(`http://localhost:3000/posts/${id}`);
    fetchPosts();
  };

  const updatePost = async (id, updatedPost) => {
    await axios.put(`http://localhost:3000/posts/${id}`, updatedPost);
    fetchPosts();
  };

  useEffect(() => {
    fetchPosts();
  }, []);

  return (
    <PostContext.Provider value={{ posts, addPost, deletePost, updatePost }}>
      {children}
    </PostContext.Provider>
  );
};