import React, { useState, useContext } from "react";
import { useNavigate } from "react-router-dom";
import { PostContext } from "../Context/PostContext";

const PostForm = () => {
  const [post, setPost] = useState({ title: "", content: "" });
  const { addPost } = useContext(PostContext);
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    addPost(post);
    navigate("/");
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Add Post</h2>
      <input
        type="text"
        placeholder="Title"
        value={post.title}
        onChange={(e) => setPost({ ...post, title: e.target.value })}
        required
      />
      <input
        type="text"
        placeholder="Content"
        value={post.content}
        onChange={(e) => setPost({ ...post, content: e.target.value })}
        required
      />
      <button type="submit">Add</button>
    </form>
  );
};

export default PostForm;