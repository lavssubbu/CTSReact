import React, { useContext } from "react";
import { PostContext } from "../Context/PostContext";
import { Link } from "react-router-dom";

const PostList = () => {
  const { posts, deletePost } = useContext(PostContext);

  return (
    <div>
      <h2>Posts</h2>
      <Link to="/add">Add Post</Link>
      <ul>
        {posts.map((post) => (
          <li key={post.id}>
            <strong>{post.title}:</strong> {post.content}
            <Link to={`/edit/${post.id}`}> Edit </Link>
            <button onClick={() => deletePost(post.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default PostList;