import React, { useState, useEffect, useContext } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import { PostContext } from "../Context/PostContext";

const PostEdit = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { updatePost } = useContext(PostContext);
  const [post, setPost] = useState({ title: "", content: "" });

  useEffect(() => {
    axios.get(`http://localhost:3000/posts/${id}`).then((res) => {
      setPost(res.data);
    });
  }, [id]);

  const handleSubmit = (e) => {
    e.preventDefault();
    updatePost(id, post);
    navigate("/");
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Edit Post</h2>
      <input
        type="text"
        value={post.title}
        onChange={(e) => setPost({ ...post, title: e.target.value })}
        required
      />
      <input
        type="text"
        value={post.content}
        onChange={(e) => setPost({ ...post, content: e.target.value })}
        required
      />
      <button type="submit">Update</button>
    </form>
  );
};

export default PostEdit;